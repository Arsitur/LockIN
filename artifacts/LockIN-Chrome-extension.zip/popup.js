function render(data) {
  const connected =
    !!data.connected && Date.now() - (data.lastSync || 0) < 12000;
  const status = document.getElementById('status');
  status.classList.toggle('connected', connected);
  status.querySelector('b').textContent = connected
    ? 'Connected to your desktop'
    : 'Waiting for your desktop connection';
  const domains = data.blockedDomains || [];
  document.getElementById('count').textContent = domains.length;
  const list = document.getElementById('domains');
  list.replaceChildren();
  for (const domain of domains.slice(0, 8)) {
    const tag = document.createElement('span');
    tag.textContent = domain;
    list.appendChild(tag);
  }
  if (domains.length > 8) {
    const tag = document.createElement('span');
    tag.textContent = `+${domains.length - 8} more`;
    list.appendChild(tag);
  }
  const session = data.snapshot?.session;
  document.getElementById('timer').textContent =
    session && session.endsAt > Date.now()
      ? `${Math.ceil((session.endsAt - Date.now()) / 60000)} min left in your session${session.testMode ? ' · test mode' : ''}`
      : '';
  const error = document.getElementById('error');
  error.hidden = !data.error;
  error.textContent = data.error || '';
}
const update = async () =>
  render(
    await chrome.storage.local.get([
      'connected',
      'lastSync',
      'blockedDomains',
      'snapshot',
      'error',
    ]),
  );
chrome.storage.onChanged.addListener(update);
update();
setInterval(update, 1000);
document.getElementById('reconnect').addEventListener('click', async () => {
  await chrome.runtime.sendMessage({ type: 'reconnect' });
  await update();
});
