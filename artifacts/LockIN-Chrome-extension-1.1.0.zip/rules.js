export function scheduleActive(schedule, now = new Date()) {
  if (
    !schedule.enabled ||
    schedule.start === schedule.end ||
    (schedule.skipUntil || 0) > now.getTime()
  )
    return false;
  const minute = now.getHours() * 60 + now.getMinutes();
  const [sh, sm] = schedule.start.split(':').map(Number),
    [eh, em] = schedule.end.split(':').map(Number);
  const start = sh * 60 + sm,
    end = eh * 60 + em;
  return start < end
    ? schedule.days.includes(now.getDay()) && minute >= start && minute < end
    : (schedule.days.includes(now.getDay()) && minute >= start) ||
        (schedule.days.includes((now.getDay() + 6) % 7) && minute < end);
}
export function getBlockedDomains(state, now = new Date()) {
  if (!state) return [];
  const domains = new Set(
    state.session && state.session.endsAt > now.getTime()
      ? state.session.domains
      : [],
  );
  for (const schedule of state.schedules || [])
    if (scheduleActive(schedule, now)) {
      for (const site of state.sites)
        if (schedule.categoryIds.includes(site.categoryId))
          domains.add(site.domain);
    }
  return [...domains].filter((d) => /^[a-z0-9.-]+$/.test(d)).sort();
}
export function makeRules(domains) {
  const types = [
    'main_frame',
    'sub_frame',
    'stylesheet',
    'script',
    'image',
    'font',
    'object',
    'xmlhttprequest',
    'ping',
    'csp_report',
    'media',
    'websocket',
    'other',
  ];
  return domains.flatMap((domain, i) => [
    {
      id: i * 2 + 1,
      priority: 1,
      action: { type: 'block' },
      condition: { requestDomains: [domain], resourceTypes: types },
    },
    {
      id: i * 2 + 2,
      priority: 1,
      action: { type: 'block' },
      condition: { initiatorDomains: [domain], resourceTypes: types },
    },
  ]);
}
export function nextBoundary(state, now = new Date()) {
  if (!state) return null;
  const times = [];
  if (state.session?.endsAt > now.getTime()) times.push(state.session.endsAt);
  for (const schedule of state.schedules || [])
    if (schedule.enabled && schedule.skipUntil > now.getTime())
      times.push(schedule.skipUntil);
  for (const schedule of state.schedules || [])
    if (schedule.enabled)
      for (let offset = -1; offset <= 8; offset++) {
        const start = new Date(now);
        start.setDate(start.getDate() + offset);
        if (!schedule.days.includes(start.getDay())) continue;
        const [sh, sm] = schedule.start.split(':').map(Number),
          [eh, em] = schedule.end.split(':').map(Number);
        start.setHours(sh, sm, 0, 0);
        const end = new Date(start);
        if (schedule.end < schedule.start) end.setDate(end.getDate() + 1);
        end.setHours(eh, em, 0, 0);
        if (start > now) times.push(start.getTime());
        if (end > now) times.push(end.getTime());
      }
  return times.length ? Math.min(...times) : null;
}
