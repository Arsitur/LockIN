import { getBlockedDomains, makeRules, nextBoundary } from './rules.js';
import { appearance } from './appearance.js';

let port = null,
  snapshot = null,
  reconnectTimer,
  heartbeatTimer,
  applied = false;
let queue = Promise.resolve();
let connectionEpoch = 0;
let lastAppearance = '';

async function applyState(state, connected) {
  snapshot = state;
  const domains = getBlockedDomains(state);
  const rules = await chrome.declarativeNetRequest.getDynamicRules();
  const nextRules = makeRules(domains);
  const currentDomains = [
    ...new Set(rules.flatMap((r) => r.condition.requestDomains || [])),
  ].sort();
  const changed =
    rules.length !== nextRules.length ||
    currentDomains.join('|') !== domains.join('|');
  if (changed) {
    const previous = new Set(
      rules.flatMap((r) => r.condition.requestDomains || []),
    );
    await chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: rules.map((r) => r.id),
      addRules: nextRules,
    });
    // Reload newly blocked tabs to terminate existing media and live connections.
    const newlyBlocked = domains.filter((d) => !previous.has(d));
    if (newlyBlocked.length) {
      const tabs = await chrome.tabs.query({});
      for (const tab of tabs) {
        try {
          const host = new URL(tab.url || '').hostname;
          if (
            tab.id &&
            newlyBlocked.some((d) => host === d || host.endsWith(`.${d}`))
          )
            await chrome.tabs.reload(tab.id, { bypassCache: true });
        } catch {
          /* A tab can disappear during a reload. */
        }
      }
    }
  }
  const next = nextBoundary(state);
  await chrome.alarms.clear('boundary');
  if (next)
    await chrome.alarms.create('boundary', {
      when: Math.max(Date.now() + 100, next),
    });
  await chrome.action.setBadgeText({
    text: domains.length ? String(domains.length) : '',
  });
  const colors = appearance(state.settings);
  await chrome.action.setBadgeBackgroundColor({ color: colors.accent });
  await chrome.action.setBadgeTextColor({ color: colors.contrast });
  if (lastAppearance !== colors.accent) {
    const canvas = new OffscreenCanvas(32, 32),
      context = canvas.getContext('2d');
    context.fillStyle = colors.accent;
    context.beginPath();
    context.roundRect(0, 0, 32, 32, 8);
    context.fill();
    context.fillStyle = colors.contrast;
    context.fillRect(8, 8, 4, 16);
    context.fillRect(8, 20, 15, 4);
    context.fillRect(18, 8, 7, 4);
    context.fillRect(21, 8, 4, 8);
    await chrome.action.setIcon({
      imageData: context.getImageData(0, 0, 32, 32),
    });
    lastAppearance = colors.accent;
  }
  await chrome.storage.local.set({
    snapshot: state,
    blockedDomains: domains,
    connected,
    lastSync: connected
      ? Date.now()
      : (await chrome.storage.local.get('lastSync')).lastSync || 0,
    error: '',
  });
  applied = true;
}
function enqueue(state, connected) {
  queue = queue
    .catch(() => {})
    .then(() => applyState(state, connected))
    .catch(async (error) => {
      applied = false;
      await chrome.storage.local.set({
        error: String(error),
        connected: false,
      });
    });
  return queue;
}
function requestSync() {
  try {
    port?.postMessage({ type: 'sync', applied });
  } catch {
    disconnect();
  }
}
function disconnect() {
  port = null;
  applied = false;
  clearInterval(heartbeatTimer);
  chrome.storage.local.set({ connected: false });
  clearTimeout(reconnectTimer);
  reconnectTimer = setTimeout(connect, 5000);
}
function connect() {
  clearTimeout(reconnectTimer);
  if (port) {
    requestSync();
    return;
  }
  const epoch = ++connectionEpoch;
  try {
    const current = chrome.runtime.connectNative('com.lockin.bridge');
    port = current;
    current.onMessage.addListener((message) => {
      if (message.type === 'state' && message.state?.version === 1)
        enqueue(message.state, true);
      else if (message.type === 'error') {
        applied = false;
        chrome.storage.local.set({ error: message.error, connected: false });
      }
    });
    current.onDisconnect.addListener(() => {
      void chrome.runtime.lastError;
      if (epoch === connectionEpoch) disconnect();
    });
    requestSync();
    clearInterval(heartbeatTimer);
    heartbeatTimer = setInterval(requestSync, 2000);
  } catch {
    disconnect();
  }
}
async function initialize() {
  const saved = await chrome.storage.local.get('snapshot');
  snapshot = saved.snapshot || null;
  if (snapshot) await enqueue(snapshot, false);
  await chrome.alarms.create('reconcile', { periodInMinutes: 0.5 });
  connect();
}
chrome.alarms.onAlarm.addListener(async () => {
  if (snapshot) await enqueue(snapshot, !!port);
  if (!port) connect();
  else requestSync();
});
chrome.runtime.onMessage.addListener((message, _sender, respond) => {
  if (message.type === 'reconnect') {
    connectionEpoch++;
    port?.disconnect();
    port = null;
    applied = false;
    clearInterval(heartbeatTimer);
    clearTimeout(reconnectTimer);
    chrome.storage.local.set({ connected: false });
    connect();
    respond({ ok: true });
  }
});
initialize().catch((error) =>
  chrome.storage.local.set({ connected: false, error: String(error) }),
);
