import { appearance } from './appearance.js';
function render(data) {
  const theme = appearance(
    data.snapshot?.settings,
    matchMedia('(prefers-color-scheme: dark)').matches,
  );
  document.documentElement.style.setProperty('--accent', theme.accent);
  document.documentElement.style.setProperty('--on-accent', theme.contrast);
  document.documentElement.classList.toggle('light', theme.light);
  const connected =
    !!data.connected && Date.now() - (data.lastSync || 0) < 12000;
  const status = document.getElementById('status');
  status.classList.toggle('connected', connected);
  status.querySelector('b').textContent = connected
    ? 'Connected to your desktop'
    : 'Waiting for your desktop connection';
  const domains = data.blockedDomains || [];
  document.getElementById('count').textContent = domains.length;
  const list = document.getElementById('domains');
  list.replaceChildren();
  for (const domain of domains.slice(0, 8)) {
    const tag = document.createElement('span');
    tag.textContent = domain;
    list.appendChild(tag);
  }
  if (domains.length > 8) {
    const tag = document.createElement('span');
    tag.textContent = `+${domains.length - 8} more`;
    list.appendChild(tag);
  }
  const session = data.snapshot?.session;
  document.getElementById('timer').textContent =
    session && session.endsAt > Date.now()
      ? `${Math.floor((session.endsAt - Date.now()) / 60000)}:${String(Math.ceil((session.endsAt - Date.now()) / 1000) % 60).padStart(2, '0')} remaining${session.testMode ? ' · test mode' : ''}`
      : '';
  const error = document.getElementById('error');
  error.hidden = !data.error;
  error.textContent = data.error || '';
}
const update = async () =>
  render(
    await chrome.storage.local.get([
      'connected',
      'lastSync',
      'blockedDomains',
      'snapshot',
      'error',
    ]),
  );
chrome.storage.onChanged.addListener(update);
update();
setInterval(update, 1000);
document.getElementById('reconnect').addEventListener('click', async () => {
  await chrome.runtime.sendMessage({ type: 'reconnect' });
  await update();
});
